const cars = [
  {id:1, make:'تويوتا', model:'كورولا', year:2018, price:'8500 دينار', img:'images/car1.jpg', desc:'حالة ممتازة، صيانة دورية.'},
  {id:2, make:'نيسان', model:'سنترا', year:2016, price:'7200 دينار', img:'images/car2.jpg', desc:'تم تركيب قطع جديدة.'},
  {id:3, make:'بي ام دبليو', model:'320i', year:2014, price:'15000 دينار', img:'images/car3.jpg', desc:'فخمة ومريحة.'},
  {id:4, make:'مرسيدس', model:'C200', year:2017, price:'19500 دينار', img:'images/car4.jpg', desc:'بحالة ممتازة وغير حادث.'},
  {id:5, make:'تويوتا', model:'راف 4', year:2019, price:'22000 دينار', img:'images/car5.jpg', desc:'مناسبة للعائلات.'}
];

const listingsEl = document.getElementById('listings');
const makeSelect = document.getElementById('filter-make');
const yearSelect = document.getElementById('filter-year');
const searchInput = document.getElementById('search');
const resetBtn = document.getElementById('reset');

function unique(values){ return [...new Set(values)]; }

function populateFilters(){
  const makes = unique(cars.map(c=>c.make));
  makes.forEach(m=>{
    const o = document.createElement('option'); o.value = m; o.textContent = m; makeSelect.appendChild(o);
  });
  const years = unique(cars.map(c=>c.year)).sort((a,b)=>b-a);
  years.forEach(y=>{
    const o = document.createElement('option'); o.value = y; o.textContent = y; yearSelect.appendChild(o);
  });
}

function render(list){
  listingsEl.innerHTML = '';
  if(list.length===0){ listingsEl.innerHTML = '<p>لا توجد سيارات تطابق البحث.</p>'; return; }
  list.forEach(c=>{
    const card = document.createElement('article'); card.className='card';
    const img = document.createElement('img'); img.src=c.img; img.alt=`${c.make} ${c.model}`;
    const title = document.createElement('h3'); title.textContent = c.make + ' ' + c.model;
    const meta = document.createElement('div'); meta.className='meta'; meta.innerHTML = `<span>${c.year}</span><span class="price">${c.price}</span>`;
    const desc = document.createElement('p'); desc.textContent = c.desc;
    card.appendChild(img); card.appendChild(title); card.appendChild(meta); card.appendChild(desc);
    listingsEl.appendChild(card);
  });
}

function applyFilters(){
  const q = searchInput.value.trim().toLowerCase();
  const make = makeSelect.value;
  const year = yearSelect.value;
  let res = cars.filter(c=>{
    const matchesQ = q==='' || (`${c.make} ${c.model}`).toLowerCase().includes(q);
    const matchesMake = make==='' || c.make===make;
    const matchesYear = year==='' || String(c.year)===String(year);
    return matchesQ && matchesMake && matchesYear;
  });
  render(res);
}

searchInput.addEventListener('input', applyFilters);
makeSelect.addEventListener('change', applyFilters);
yearSelect.addEventListener('change', applyFilters);
resetBtn.addEventListener('click', ()=>{
  searchInput.value=''; makeSelect.value=''; yearSelect.value=''; applyFilters();
});

document.getElementById('contact-form').addEventListener('submit', (e)=>{
  e.preventDefault();
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const message = document.getElementById('message').value;
  document.getElementById('contact-result').textContent = 'تم إرسال الرسالة — سنتواصل معك قريبًا، ' + name + '.';
  e.target.reset();
});

populateFilters();
render(cars);
